document.addEventListener('DOMContentLoaded',()=>{const el=document.getElementById('defer');if(el)el.textContent='Deferred app script executed after HTML parsing.';});
