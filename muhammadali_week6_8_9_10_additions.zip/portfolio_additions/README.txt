PORTFOLIO ADDITIONS

Upload the four folders (Week 6, Week 8, Week 9, Week 10) into the ROOT of your Web-programming repository. Keep the existing portfolio.css in the root.

Then add links to these folders in the Coursework section of your root index.html:
Week 6 -> Week%206/index.html
Week 8 -> Week%208/index.html
Week 9 -> Week%209/index.html
Week 10 -> Week%2010/index.html

All pages link to ../portfolio.css and also include a small local style layer so the tasks remain styled. API pages require an internet connection. Forms are front-end demos and do not submit to a real server. Lighthouse scores/screenshots must be generated from your own website; no fake scores are included.
